package com.aivortex.hunter.master;

import android.Manifest;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

/**
 * MainActivity - Entry point for AI-Hunter Pro application
 * Features:
 * - Manages permissions and accessibility service
 * - Initializes floating overlay service
 * - Provides user interface for feature toggling
 * - Handles system integration and optimizations
 */
public class MainActivity extends AppCompatActivity {
    
    private static final String TAG = "AIHunterPro";
    private static final int OVERLAY_PERMISSION_REQUEST = 1001;
    private static final int ACCESSIBILITY_REQUEST = 1002;
    private static final int STORAGE_PERMISSION_REQUEST = 1003;
    private static final int BATTERY_OPTIMIZATION_REQUEST = 1004;
    
    // UI Components
    private TextView tvStatus;
    private TextView tvCpuUsage;
    private TextView tvRamUsage;
    private TextView tvFps;
    private TextView tvNetworkPing;
    
    // Toggle buttons for all 13 features
    private ToggleButton btnAutoHeadshot;
    private ToggleButton btnAimLock;
    private ToggleButton btnBulletTrack;
    private ToggleButton btnZeroRecoil;
    private ToggleButton btnInstaKill;
    private ToggleButton btnSpeedX;
    private ToggleButton btnNightMode;
    private ToggleButton btnInvisiblePanel;
    private ToggleButton btnRamPurge;
    private ToggleButton btnCpuOverclock;
    private ToggleButton btnFpsStabilizer;
    private ToggleButton btnNetworkFixer;
    private ToggleButton btnDeviceCooler;
    
    // Native library loader
    static {
        System.loadLibrary("ai-hunter-native");
    }
    
    // JNI Methods for all 13 features
    public native boolean nativeInitAIHunter();
    public native void nativeToggleAutoHeadshot(boolean enabled);
    public native void nativeToggleAimLock(boolean enabled);
    public native void nativeToggleBulletTrack(boolean enabled);
    public native void nativeToggleZeroRecoil(boolean enabled);
    public native void nativeToggleInstaKill(boolean enabled);
    public native void nativeToggleSpeedX(boolean enabled);
    public native void nativeToggleNightMode(boolean enabled);
    public native void nativeToggleInvisiblePanel(boolean enabled);
    public native void nativeToggleRamPurge(boolean enabled);
    public native void nativeToggleCpuOverclock(boolean enabled);
    public native void nativeToggleFpsStabilizer(boolean enabled);
    public native void nativeToggleNetworkFixer(boolean enabled);
    public native void nativeToggleDeviceCooler(boolean enabled);
    
    public native float[] nativeGetPerformanceMetrics();
    public native String nativeGetSystemInfo();
    public native void nativeOptimizeMemory();
    public native void nativeOptimizeNetwork();
    public native void nativeOptimizeThermal();
    
    // Performance monitoring
    private Timer performanceTimer;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // Set transparent background
        getWindow().setFlags(
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );
        
        // Initialize native library
        if (!nativeInitAIHunter()) {
            Log.e(TAG, "Failed to initialize native AI-Hunter library");
            showErrorDialog("Native library initialization failed. The app may not function properly.");
        }
        
        setContentView(R.layout.activity_main);
        
        initializeUIComponents();
        setupButtonListeners();
        checkAndRequestPermissions();
        startPerformanceMonitoring();
        
        // Start floating service if permissions are granted
        if (checkOverlayPermission() && checkAccessibilityService()) {
            startFloatingService();
        }
        
        Log.i(TAG, "AI-Hunter Pro MainActivity initialized successfully");
    }
    
    /**
     * Initialize all UI components from layout
     */
    private void initializeUIComponents() {
        tvStatus = findViewById(R.id.tv_status);
        tvCpuUsage = findViewById(R.id.tv_cpu_usage);
        tvRamUsage = findViewById(R.id.tv_ram_usage);
        tvFps = findViewById(R.id.tv_fps);
        tvNetworkPing = findViewById(R.id.tv_network_ping);
        
        // Initialize all 13 toggle buttons
        btnAutoHeadshot = findViewById(R.id.btn_auto_headshot);
        btnAimLock = findViewById(R.id.btn_aim_lock);
        btnBulletTrack = findViewById(R.id.btn_bullet_track);
        btnZeroRecoil = findViewById(R.id.btn_zero_recoil);
        btnInstaKill = findViewById(R.id.btn_insta_kill);
        btnSpeedX = findViewById(R.id.btn_speed_x);
        btnNightMode = findViewById(R.id.btn_night_mode);
        btnInvisiblePanel = findViewById(R.id.btn_invisible_panel);
        btnRamPurge = findViewById(R.id.btn_ram_purge);
        btnCpuOverclock = findViewById(R.id.btn_cpu_overclock);
        btnFpsStabilizer = findViewById(R.id.btn_fps_stabilizer);
        btnNetworkFixer = findViewById(R.id.btn_network_fixer);
        btnDeviceCooler = findViewById(R.id.btn_device_cooler);
        
        // Display system information
        String systemInfo = nativeGetSystemInfo();
        Log.d(TAG, "System Info: " + systemInfo);
    }
    
    /**
     * Setup listeners for all 13 toggle buttons
     */
    private void setupButtonListeners() {
        // Auto-Headshot AI
        btnAutoHeadshot.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleAutoHeadshot(isChecked);
            if (isChecked) {
                showToast("Auto-Headshot AI Activated");
            } else {
                showToast("Auto-Headshot AI Deactivated");
            }
        });
        
        // Aim-Lock Pro
        btnAimLock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleAimLock(isChecked);
            if (isChecked) {
                showToast("Aim-Lock Pro: Target Lock Engaged");
            } else {
                showToast("Aim-Lock Pro: Disengaged");
            }
        });
        
        // Bullet-Track V2
        btnBulletTrack.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleBulletTrack(isChecked);
            if (isChecked) {
                showToast("Bullet-Track V2: Predictive Targeting Active");
            } else {
                showToast("Bullet-Track V2: Disabled");
            }
        });
        
        // Zero-Recoil
        btnZeroRecoil.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleZeroRecoil(isChecked);
            if (isChecked) {
                showToast("Zero-Recoil: Weapon Stabilization Active");
            } else {
                showToast("Zero-Recoil: Disabled");
            }
        });
        
        // Insta-Kill Mode
        btnInstaKill.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleInstaKill(isChecked);
            if (isChecked) {
                showToast("⚠️ Insta-Kill Mode: ACTIVATED - Use with Caution!");
            } else {
                showToast("Insta-Kill Mode: Deactivated");
            }
        });
        
        // Speed-X AI
        btnSpeedX.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleSpeedX(isChecked);
            if (isChecked) {
                showToast("Speed-X AI: Temporal Optimization Active");
            } else {
                showToast("Speed-X AI: Disabled");
            }
        });
        
        // Night-Mode Overlay
        btnNightMode.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleNightMode(isChecked);
            if (isChecked) {
                showToast("Night-Mode Overlay: Enhanced Visibility Active");
            } else {
                showToast("Night-Mode Overlay: Disabled");
            }
        });
        
        // Invisible Panel
        btnInvisiblePanel.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleInvisiblePanel(isChecked);
            if (isChecked) {
                showToast("Panel Invisibility: Active");
            } else {
                showToast("Panel: Visible");
            }
        });
        
        // RAM-Purge AI
        btnRamPurge.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleRamPurge(isChecked);
            if (isChecked) {
                nativeOptimizeMemory();
                showToast("RAM-Purge AI: Memory Optimization Active");
            } else {
                showToast("RAM-Purge AI: Disabled");
            }
        });
        
        // CPU-Overclock
        btnCpuOverclock.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleCpuOverclock(isChecked);
            if (isChecked) {
                showToast("CPU-Overclock: Performance Boost Active");
            } else {
                showToast("CPU-Overclock: Disabled");
            }
        });
        
        // FPS-Stabilizer
        btnFpsStabilizer.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleFpsStabilizer(isChecked);
            if (isChecked) {
                showToast("FPS-Stabilizer: Frame Rate Optimization Active");
            } else {
                showToast("FPS-Stabilizer: Disabled");
            }
        });
        
        // Network-Ping-Fixer
        btnNetworkFixer.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleNetworkFixer(isChecked);
            if (isChecked) {
                nativeOptimizeNetwork();
                showToast("Network-Ping-Fixer: Latency Optimization Active");
            } else {
                showToast("Network-Ping-Fixer: Disabled");
            }
        });
        
        // Device-Cooler
        btnDeviceCooler.setOnCheckedChangeListener((buttonView, isChecked) -> {
            nativeToggleDeviceCooler(isChecked);
            if (isChecked) {
                nativeOptimizeThermal();
                showToast("Device-Cooler: Thermal Management Active");
            } else {
                showToast("Device-Cooler: Disabled");
            }
        });
        
        // Start Service Button
        Button btnStartService = findViewById(R.id.btn_start_service);
        btnStartService.setOnClickListener(v -> {
            if (checkOverlayPermission() && checkAccessibilityService()) {
                startFloatingService();
                showToast("AI-Hunter Pro Service Started");
            } else {
                requestAllPermissions();
            }
        });
        
        // Stop Service Button
        Button btnStopService = findViewById(R.id.btn_stop_service);
        btnStopService.setOnClickListener(v -> {
            stopService(new Intent(MainActivity.this, FloatingService.class));
            showToast("AI-Hunter Pro Service Stopped");
        });
    }
    
    /**
     * Check and request all necessary permissions
     */
    private void checkAndRequestPermissions() {
        if (!checkOverlayPermission()) {
            requestOverlayPermission();
        }
        
        if (!checkAccessibilityService()) {
            requestAccessibilityService();
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        STORAGE_PERMISSION_REQUEST);
            }
        }
    }
    
    /**
     * Check if overlay permission is granted
     */
    private boolean checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return Settings.canDrawOverlays(this);
        }
        return true;
    }
    
    /**
     * Check if accessibility service is enabled
     */
    private boolean checkAccessibilityService() {
        AccessibilityManager am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);
        List<AccessibilityServiceInfo> enabledServices = am.getEnabledAccessibilityServiceList(
                AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        
        for (AccessibilityServiceInfo service : enabledServices) {
            if (service.getId().contains(getPackageName())) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Request overlay permission
     */
    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, OVERLAY_PERMISSION_REQUEST);
        }
    }
    
    /**
     * Request accessibility service
     */
    private void requestAccessibilityService() {
        Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
        startActivityForResult(intent, ACCESSIBILITY_REQUEST);
    }
    
    /**
     * Request all permissions at once
     */
    private void requestAllPermissions() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissions Required")
                .setMessage("AI-Hunter Pro requires the following permissions:\n\n" +
                        "1. Display Over Other Apps (For floating panel)\n" +
                        "2. Accessibility Service (For automation)\n" +
                        "3. Storage Permission (For logs and configs)\n\n" +
                        "Please grant these permissions for full functionality.")
                .setPositiveButton("Grant Permissions", (dialog, which) -> {
                    requestOverlayPermission();
                    new Handler().postDelayed(this::requestAccessibilityService, 1000);
                })
                .setNegativeButton("Cancel", null)
                .show();
    }
    
    /**
     * Start the floating overlay service
     */
    private void startFloatingService() {
        Intent serviceIntent = new Intent(this, FloatingService.class);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        
        tvStatus.setText(getString(R.string.service_enabled));
        tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_green_light));
    }
    
    /**
     * Start performance monitoring
     */
    private void startPerformanceMonitoring() {
        performanceTimer = new Timer();
        performanceTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                updatePerformanceMetrics();
            }
        }, 0, 1000); // Update every second
    }
    
    /**
     * Update performance metrics on UI
     */
    private void updatePerformanceMetrics() {
        float[] metrics = nativeGetPerformanceMetrics();
        
        uiHandler.post(() -> {
            if (metrics != null && metrics.length >= 4) {
                tvCpuUsage.setText(String.format("CPU Usage: %.1f%%", metrics[0]));
                tvRamUsage.setText(String.format("RAM Usage: %.0f MB", metrics[1]));
                tvFps.setText(String.format("FPS: %.0f", metrics[2]));
                tvNetworkPing.setText(String.format("Ping: %.0fms", metrics[3]));
            }
        });
    }
    
    /**
     * Show toast message
     */
    private void showToast(String message) {
        uiHandler.post(() -> Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show());
    }
    
    /**
     * Show error dialog
     */
    private void showErrorDialog(String message) {
        uiHandler.post(() -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
            builder.setTitle("Error")
                    .setMessage(message)
                    .setPositiveButton("OK", null)
                    .show();
        });
    }
    
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        
        if (requestCode == OVERLAY_PERMISSION_REQUEST) {
            if (checkOverlayPermission()) {
                showToast("Overlay permission granted");
            } else {
                showToast("Overlay permission denied - Floating panel won't work");
            }
        } else if (requestCode == ACCESSIBILITY_REQUEST) {
            if (checkAccessibilityService()) {
                showToast("Accessibility service enabled");
            } else {
                showToast("Accessibility service not enabled - Automation won't work");
            }
        }
    }
    
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        
        if (requestCode == STORAGE_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showToast("Storage permission granted");
            } else {
                showToast("Storage permission denied");
            }
        }
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (performanceTimer != null) {
            performanceTimer.cancel();
            performanceTimer = null;
        }
        
        // Clean up native resources
        nativeToggleAutoHeadshot(false);
        nativeToggleAimLock(false);
        nativeToggleBulletTrack(false);
        nativeToggleZeroRecoil(false);
        nativeToggleInstaKill(false);
        nativeToggleSpeedX(false);
        nativeToggleNightMode(false);
        nativeToggleInvisiblePanel(false);
        nativeToggleRamPurge(false);
        nativeToggleCpuOverclock(false);
        nativeToggleFpsStabilizer(false);
        nativeToggleNetworkFixer(false);
        nativeToggleDeviceCooler(false);
        
        Log.i(TAG, "AI-Hunter Pro MainActivity destroyed");
    }
}