package com.aivortex.hunter.master;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

/**
 * FloatingService - Provides draggable overlay panel with 13 AI-powered features
 * Features:
 * - Physics-based draggable panel with smooth movement
 * - Minimize to icon functionality
 * - Real-time performance monitoring
 * - Gesture detection and handling
 * - System optimization controls
 */
public class FloatingService extends Service implements SensorEventListener {
    
    private static final String TAG = "FloatingService";
    private static final String CHANNEL_ID = "ai_hunter_channel";
    private static final int NOTIFICATION_ID = 101;
    
    private WindowManager windowManager;
    private WindowManager.LayoutParams panelParams;
    private WindowManager.LayoutParams iconParams;
    
    private View floatingPanel;
    private View floatingIcon;
    
    private boolean isPanelVisible = true;
    private boolean isMinimized = false;
    
    // Physics and movement variables
    private float initialX, initialY;
    private float initialTouchX, initialTouchY;
    private long lastClickTime = 0;
    private static final long DOUBLE_CLICK_TIME_DELTA = 300;
    
    private int screenWidth, screenHeight;
    private int panelWidth, panelHeight;
    private int iconSize = 60;
    
    private float velocityX = 0, velocityY = 0;
    private float friction = 0.9f;
    private boolean isDragging = false;
    
    private Timer physicsTimer;
    private final Handler physicsHandler = new Handler(Looper.getMainLooper());
    
    // Sensors for advanced features
    private SensorManager sensorManager;
    private Sensor accelerometer;
    private Sensor gyroscope;
    
    private PowerManager.WakeLock wakeLock;
    
    // UI Components
    private TextView tvTime, tvStatus;
    private Button btnClose, btnMinimize;
    private LinearLayout panelHeader;
    
    // Animation
    private Animation fadeIn, fadeOut, slideIn, slideOut;
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "FloatingService onCreate");
        
        initializeWindowManager();
        initializeSensors();
        initializeAnimations();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, createNotification());
        
        // Keep CPU awake for real-time processing
        acquireWakeLock();
        
        // Start physics simulation
        startPhysicsSimulation();
    }
    
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i(TAG, "FloatingService onStartCommand");
        
        if (floatingPanel == null) {
            createFloatingPanel();
        }
        
        if (floatingIcon == null) {
            createFloatingIcon();
        }
        
        // Update UI initially
        updateTime();
        startTimeUpdater();
        
        return START_STICKY;
    }
    
    /**
     * Initialize window manager and get screen dimensions
     */
    private void initializeWindowManager() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getMetrics(metrics);
        
        screenWidth = metrics.widthPixels;
        screenHeight = metrics.heightPixels;
        
        Log.d(TAG, "Screen dimensions: " + screenWidth + "x" + screenHeight);
    }
    
    /**
     * Initialize sensors for motion detection
     */
    private void initializeSensors() {
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        
        if (sensorManager != null) {
            accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
            
            if (accelerometer != null) {
                sensorManager.registerListener(this, accelerometer, 
                    SensorManager.SENSOR_DELAY_GAME);
            }
            
            if (gyroscope != null) {
                sensorManager.registerListener(this, gyroscope,
                    SensorManager.SENSOR_DELAY_GAME);
            }
        }
    }
    
    /**
     * Initialize animations
     */
    private void initializeAnimations() {
        fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in);
        fadeOut = AnimationUtils.loadAnimation(this, android.R.anim.fade_out);
        slideIn = AnimationUtils.loadAnimation(this, android.R.anim.slide_in_left);
        slideOut = AnimationUtils.loadAnimation(this, android.R.anim.slide_out_right);
        
        fadeIn.setDuration(300);
        fadeOut.setDuration(300);
        slideIn.setDuration(400);
        slideOut.setDuration(400);
    }
    
    /**
     * Create floating panel with all controls
     */
    private void createFloatingPanel() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        floatingPanel = inflater.inflate(R.layout.floating_panel, null);
        
        // Get panel dimensions
        floatingPanel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
        panelWidth = floatingPanel.getMeasuredWidth();
        panelHeight = floatingPanel.getMeasuredHeight();
        
        // Setup window parameters for panel
        panelParams = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH |
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        );
        
        // Position panel at top-right initially
        panelParams.gravity = Gravity.TOP | Gravity.END;
        panelParams.x = 20;
        panelParams.y = 100;
        
        // Setup UI components
        setupPanelComponents();
        
        // Add panel to window
        try {
            windowManager.addView(floatingPanel, panelParams);
            isPanelVisible = true;
            Log.i(TAG, "Floating panel added to window");
        } catch (Exception e) {
            Log.e(TAG, "Error adding floating panel: " + e.getMessage());
        }
    }
    
    /**
     * Create minimized floating icon
     */
    private void createFloatingIcon() {
        LayoutInflater inflater = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
        floatingIcon = inflater.inflate(R.layout.small_icon, null);
        
        // Setup window parameters for icon
        iconParams = new WindowManager.LayoutParams(
            iconSize,
            iconSize,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        );
        
        // Position icon at bottom-right initially
        iconParams.gravity = Gravity.BOTTOM | Gravity.END;
        iconParams.x = 20;
        iconParams.y = 100;
        
        // Setup icon click listener
        floatingIcon.setOnClickListener(v -> {
            long clickTime = System.currentTimeMillis();
            if (clickTime - lastClickTime < DOUBLE_CLICK_TIME_DELTA) {
                // Double click - show panel
                showPanel();
            } else {
                // Single click - show brief toast
                showToast("Double-click to open panel");
            }
            lastClickTime = clickTime;
        });
        
        floatingIcon.setOnTouchListener(new View.OnTouchListener() {
            private float iconInitialX, iconInitialY;
            private float iconInitialTouchX, iconInitialTouchY;
            
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        iconInitialX = iconParams.x;
                        iconInitialY = iconParams.y;
                        iconInitialTouchX = event.getRawX();
                        iconInitialTouchY = event.getRawY();
                        return true;
                        
                    case MotionEvent.ACTION_MOVE:
                        float deltaX = event.getRawX() - iconInitialTouchX;
                        float deltaY = event.getRawY() - iconInitialTouchY;
                        
                        iconParams.x = (int) (iconInitialX + deltaX);
                        iconParams.y = (int) (iconInitialY + deltaY);
                        
                        windowManager.updateViewLayout(floatingIcon, iconParams);
                        return true;
                        
                    case MotionEvent.ACTION_UP:
                        // Snap to edges
                        snapToEdge(iconParams, true);
                        return true;
                }
                return false;
            }
        });
        
        // Add icon to window initially hidden
        floatingIcon.setVisibility(View.GONE);
        try {
            windowManager.addView(floatingIcon, iconParams);
            Log.i(TAG, "Floating icon added to window");
        } catch (Exception e) {
            Log.e(TAG, "Error adding floating icon: " + e.getMessage());
        }
    }
    
    /**
     * Setup panel components and listeners
     */
    private void setupPanelComponents() {
        // Get references to UI components
        panelHeader = floatingPanel.findViewById(R.id.panel_header);
        tvTime = floatingPanel.findViewById(R.id.tv_time);
        tvStatus = floatingPanel.findViewById(R.id.tv_status);
        btnClose = floatingPanel.findViewById(R.id.btn_close);
        btnMinimize = floatingPanel.findViewById(R.id.btn_minimize);
        
        // Setup drag listener for panel header
        panelHeader.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                handlePanelTouch(event);
                return true;
            }
        });
        
        // Close button
        btnClose.setOnClickListener(v -> {
            hidePanel();
            showToast("Panel closed. Click icon to reopen.");
        });
        
        // Minimize button
        btnMinimize.setOnClickListener(v -> minimizeToIcon());
        
        // Setup touch listener for the entire panel for physics
        floatingPanel.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    isDragging = false;
                    velocityX = 0;
                    velocityY = 0;
                }
                return false;
            }
        });
    }
    
    /**
     * Handle panel touch events for dragging
     */
    private void handlePanelTouch(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                initialX = panelParams.x;
                initialY = panelParams.y;
                initialTouchX = event.getRawX();
                initialTouchY = event.getRawY();
                isDragging = true;
                velocityX = 0;
                velocityY = 0;
                break;
                
            case MotionEvent.ACTION_MOVE:
                float deltaX = event.getRawX() - initialTouchX;
                float deltaY = event.getRawY() - initialTouchY;
                
                panelParams.x = (int) (initialX + deltaX);
                panelParams.y = (int) (initialY + deltaY);
                
                // Calculate velocity for physics
                velocityX = deltaX;
                velocityY = deltaY;
                
                windowManager.updateViewLayout(floatingPanel, panelParams);
                break;
                
            case MotionEvent.ACTION_UP:
                isDragging = false;
                // Apply snap to edge with physics
                snapToEdge(panelParams, false);
                break;
        }
    }
    
    /**
     * Snap view to nearest screen edge with physics
     */
    private void snapToEdge(WindowManager.LayoutParams params, boolean isIcon) {
        int viewWidth = isIcon ? iconSize : panelWidth;
        int viewHeight = isIcon ? iconSize : panelHeight;
        
        int centerX = params.x + viewWidth / 2;
        int centerY = params.y + viewHeight / 2;
        
        // Determine nearest edge
        if (centerX < screenWidth / 2) {
            // Snap to left
            params.x = 0;
        } else {
            // Snap to right
            params.x = screenWidth - viewWidth;
        }
        
        // Keep within vertical bounds
        if (params.y < 0) params.y = 0;
        if (params.y > screenHeight - viewHeight) params.y = screenHeight - viewHeight;
        
        // Apply with animation
        if (isIcon) {
            windowManager.updateViewLayout(floatingIcon, params);
        } else {
            windowManager.updateViewLayout(floatingPanel, params);
        }
    }
    
    /**
     * Start physics simulation for smooth movement
     */
    private void startPhysicsSimulation() {
        physicsTimer = new Timer();
        physicsTimer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                physicsHandler.post(() -> {
                    if (!isDragging && (Math.abs(velocityX) > 0.1 || Math.abs(velocityY) > 0.1)) {
                        // Apply friction
                        velocityX *= friction;
                        velocityY *= friction;
                        
                        // Update position
                        panelParams.x += velocityX;
                        panelParams.y += velocityY;
                        
                        // Boundary checking
                        if (panelParams.x < 0) {
                            panelParams.x = 0;
                            velocityX *= -0.5; // Bounce
                        }
                        if (panelParams.x > screenWidth - panelWidth) {
                            panelParams.x = screenWidth - panelWidth;
                            velocityX *= -0.5;
                        }
                        if (panelParams.y < 0) {
                            panelParams.y = 0;
                            velocityY *= -0.5;
                        }
                        if (panelParams.y > screenHeight - panelHeight) {
                            panelParams.y = screenHeight - panelHeight;
                            velocityY *= -0.5;
                        }
                        
                        windowManager.updateViewLayout(floatingPanel, panelParams);
                    }
                });
            }
        }, 0, 16); // ~60 FPS
    }
    
    /**
     * Minimize panel to icon
     */
    private void minimizeToIcon() {
        if (floatingPanel != null && floatingIcon != null) {
            floatingPanel.startAnimation(fadeOut);
            floatingPanel.setVisibility(View.GONE);
            
            floatingIcon.setVisibility(View.VISIBLE);
            floatingIcon.startAnimation(fadeIn);
            
            isMinimized = true;
            showToast("Panel minimized to icon");
        }
    }
    
    /**
     * Show panel from minimized state
     */
    private void showPanel() {
        if (floatingPanel != null && floatingIcon != null && isMinimized) {
            floatingIcon.startAnimation(fadeOut);
            floatingIcon.setVisibility(View.GONE);
            
            floatingPanel.setVisibility(View.VISIBLE);
            floatingPanel.startAnimation(fadeIn);
            
            isMinimized = false;
        }
    }
    
    /**
     * Hide panel completely
     */
    private void hidePanel() {
        if (floatingPanel != null) {
            floatingPanel.startAnimation(fadeOut);
            floatingPanel.setVisibility(View.GONE);
            isPanelVisible = false;
        }
    }
    
    /**
     * Update time display
     */
    private void updateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        String currentTime = sdf.format(new Date());
        
        if (tvTime != null) {
            tvTime.setText(currentTime);
        }
    }
    
    /**
     * Start time updater
     */
    private void startTimeUpdater() {
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                physicsHandler.post(() -> updateTime());
            }
        }, 0, 1000);
    }
    
    /**
     * Create notification channel (Android O+)
     */
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "AI-Hunter Pro Service",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("AI-Hunter Pro overlay service is running");
            channel.setShowBadge(false);
            
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }
    
    /**
     * Create foreground notification
     */
    private Notification createNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("AI-Hunter Pro")
            .setContentText("Overlay service is running")
            .setSmallIcon(R.drawable.ic_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET);
        
        return builder.build();
    }
    
    /**
     * Acquire wake lock to keep CPU awake
     */
    private void acquireWakeLock() {
        PowerManager powerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        if (powerManager != null) {
            wakeLock = powerManager.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "AIHunterPro::WakeLock"
            );
            wakeLock.acquire(10 * 60 * 1000L /*10 minutes*/);
        }
    }
    
    /**
     * Show toast message
     */
    private void showToast(String message) {
        physicsHandler.post(() -> 
            Toast.makeText(FloatingService.this, message, Toast.LENGTH_SHORT).show());
    }
    
    // SensorEventListener methods
    @Override
    public void onSensorChanged(SensorEvent event) {
        // Handle sensor data for advanced features
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            // Process accelerometer data for motion detection
            float x = event.values[0];
            float y = event.values[1];
            float z = event.values[2];
            
            // Implement motion-based features here
        }
    }
    
    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // Handle accuracy changes
    }
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
    
    @Override
    public void onDestroy() {
        Log.i(TAG, "FloatingService onDestroy");
        
        // Clean up resources
        if (physicsTimer != null) {
            physicsTimer.cancel();
            physicsTimer = null;
        }
        
        if (sensorManager != null) {
            sensorManager.unregisterListener(this);
        }
        
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        
        // Remove views from window
        if (floatingPanel != null) {
            windowManager.removeView(floatingPanel);
        }
        
        if (floatingIcon != null) {
            windowManager.removeView(floatingIcon);
        }
        
        super.onDestroy();
    }
}